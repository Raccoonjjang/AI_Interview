import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import LogoImage from '../Asset/Image/Logo.png';
import styles from './Navbar.module.css';

export default function Navbar() {
    const [isDropdownOpen, setDropdownOpen] = useState(false);

    const handleLogout = () => {
        sessionStorage.removeItem('userId');
        window.location.href = '/';
    };

    const toggleDropdown = () => {
        setDropdownOpen(!isDropdownOpen);
    };

    return (
        <div className={styles['White-nav']}>
            <Link to="/">
                <img className={styles.Logo} src={LogoImage} alt="Logo" />
            </Link>
            <div className={styles['Text-nav-container']}>
                <h4 onClick={toggleDropdown}>My Account ▼</h4>
                {isDropdownOpen && (
                    <div className={styles['dropdown-menu']}>
                        <h5><a href="/mypage">My Page</a></h5>
                        <h5><a href="/myaccount">My Account</a></h5>
                        <h5 onClick={handleLogout}>Logout</h5>
                    </div>
                )}
            </div>
        </div>
    );
}
