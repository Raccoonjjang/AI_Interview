import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Navbar.module.css';
import LogoImage from '../Asset/Image/Logo.png';

export default function Navbar() {
  
  return (
    <div className={styles['White-nav']}>
      <Link to="/">
        <img className={styles.Logo} src={LogoImage} alt="Logo" />
      </Link>
      <div className={styles['Text-nav-container']}>
        <h4>
          <Link to="/login">Login</Link>
        </h4>
        <h4>
          <Link to="/regist">Regist</Link>
        </h4>
      </div>
    </div>
  );
}