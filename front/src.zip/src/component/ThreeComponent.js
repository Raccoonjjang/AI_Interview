import React, { useRef, Suspense, useEffect } from 'react';
import { Canvas, useFrame } from 'react-three-fiber';
import { OrbitControls } from '@react-three/drei';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader';

const Model = ({ gltf }) => {
  const modelRef = useRef();

  useFrame(() => {
    if (modelRef.current) {
      modelRef.current.rotation.x += 0.01;
      modelRef.current.rotation.y += 0.01;
    }
  });

  return (
    <group>
      {/* You can add lights or other components here */}
      {gltf && <primitive object={gltf.scene} />}
    </group>
  );
};

export default function ThreeComponent() {
  const gltfLoader = new GLTFLoader();
  const [loadedModel, setLoadedModel] = React.useState(null);

  useEffect(() => {
    // Load the model using GLTFLoader
    gltfLoader.load('/ThreeComponent', (gltf) => {
      setLoadedModel(gltf);
    });
  }, [gltfLoader]);

  return (
    <Canvas style={{ width: '100%', height: '100%' }} onCreated={({ gl }) => gl.setPixelRatio(window.devicePixelRatio)}>
      <OrbitControls />
      <ambientLight intensity={1} />
      {/* Load the 3D model using GLTFLoader */}
      <Suspense fallback={null}>
        <Model gltf={loadedModel} />
      </Suspense>
    </Canvas>
  );
}
