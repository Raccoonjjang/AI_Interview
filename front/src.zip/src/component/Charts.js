import React, { useState, useEffect } from "react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function Charts() {
  const [userData, setUserData] = useState([]);

  useEffect(() => {
    const userId = sessionStorage.getItem("userId");
    console.log("userId:", userId);

    if (userId) {
      fetch(`http://localhost:4000/Charts/${userId}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          userId,
        }),
      })
      .then((response) => response.json())
      .then((data) => {
        console.log("Server response:", data);
        if (data.message === "success") {
          console.log(data.userData[0].date_log)
          setUserData(data.userData.date_log); // 서버에서 가져온 userData.data_log로 설정
        } else {
          // 실패 처리
        }
      })
      .catch((error) => {
        console.error("Error sending data to server:", error);
      });
    }
  }, []);

  // userData가 유효한 배열인지 확인하여 데이터 생성
  const tempData = userData && userData.length > 0 ? userData.map((dataPoint) => ({
    name: dataPoint.date, // 날짜 데이터
    uv: dataPoint.uv, // userData의 데이터에 따라 변경해야 합니다.
    pv: dataPoint.pv, // userData의 데이터에 따라 변경해야 합니다.
  })) : [];

  return (
    <ResponsiveContainer width="100%" height={400}>
      <LineChart
        data={tempData} // 서버에서 가져온 userData.data_log를 사용
        margin={{
          top: 5,
          right: 30,
          left: 20,
          bottom: 5,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="name" />
        <YAxis />
        <Tooltip />
        <Legend />
        <Line type="monotone" dataKey="pv" stroke="#8884d8" activeDot={{ r: 8 }} />
        <Line type="monotone" dataKey="uv" stroke="#82ca9d" />
      </LineChart>
    </ResponsiveContainer>
  );
}
