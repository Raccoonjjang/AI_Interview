import styles from './Report.module.css';
import React, { useEffect, useRef, useState , useCallback} from 'react';
import Chart from 'chart.js/auto';
import kyungji from '../Asset/Image/Logo.png';

export default function AverReport() {
    const [voiceData, setVoiceData] = useState({
        PITCH: "Medium Volatility",
        SPEED: 39,
        DICTION: "Good",
        CONTINUERS: 48.48,
        SILENCE: 100,
        SIMILARITY:12.12
    });
    const getNumericalVoiceData = useCallback(() => {
        return [
            voiceData.SPEED,
            voiceData.CONTINUERS,
            voiceData.SILENCE,
            voiceData.SIMILARITY
        ];
    }, [voiceData]); // Dependencies of the function

    const userId = sessionStorage.getItem('userId');
    const [userName, setUserName] = useState("");
    
    const [eyedata, setEyedata] = useState([30, 25, 20, 25]);
    const [emotionData, setEmotionData] = useState([30, 25, 20, 25]); 
    const [headPositionData, setHeadPositionData] = useState([30, 25, 20]);
    

    const chartRefEye = useRef(null);
    const chartRefEmotion = useRef(null);
    const chartRefHead = useRef(null);
    const chartRefVoice = useRef(null);

    const [isLoading, setIsLoading] = useState(true);

    console.log(userId);

    useEffect(() => {
        // 페이지가 로드될 때 서버에 데이터 요청
        fetch('http://localhost:4000/Averreport', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                userId: userId
            }),
        })
        .then(response => response.json())
        .then(data => {
            if (data.message === 'success') {
                setEyedata([data.userData.s_center, data.userData.s_left, data.userData.s_right, data.userData.blink]);
                setEmotionData([data.userData.happy, data.userData.sad, data.userData.surprise, data.userData.neutral]);
                setHeadPositionData([data.userData.s_center, data.userData.s_left, data.userData.s_right]);
                setUserName(data.userData.NAME);


                // 이 부분을 객체로 수정
                setVoiceData({
                    PITCH: data.userData.PITCH,
                    SPEED: data.userData.SPEED,
                    DICTION: data.userData.DICTION,
                    CONTINUERS: data.userData.CONTINUERS,
                    SILENCE: data.userData.SILENCE,
                    SIMILARITY: data.userData.SIMILARITY
                });
                setIsLoading(false);  // 로딩 상태 변경
            } else {
                console.error("Server returned an error:", data.message);
                setIsLoading(false);  // 에러 발생 시 로딩 상태 변경
            }
        })
        .catch(error => {
            console.error("Error fetching data:", error);
            setIsLoading(false);  // 에러 발생 시 로딩 상태 변경
        });
    }, [userId]);
    // -----------------------------------차트 생성 부분-------------------------
    //시야 그래프
    useEffect(() => {

        if (!isLoading && chartRefEye.current) {
            const donutChartEye = new Chart(chartRefEye.current, {
                type: 'doughnut',
                data: {
                    labels: ['중앙', '왼쪽', '오른쪽', '깜빡임'],
                    datasets: [{
                        data: eyedata,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'left',
                        },
                    },
                },
            });
            return () => {
                donutChartEye.destroy();
            };
        }
    }, [eyedata, isLoading]);
    //머리 회전 그래프
    useEffect(() => {
        if (!isLoading && chartRefHead.current) {
            const donutChartHead = new Chart(chartRefHead.current, {
                type: 'doughnut',
                data: {
                    labels: ['중앙', '좌로 치우침', '우로 치우침'],
                    datasets: [{
                        data: headPositionData,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56'],
                        hoverOffset: 3
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'left',
                        },
                    },
                },
            });
            return () => {
                donutChartHead.destroy();
            };
        }
    }, [headPositionData, isLoading]);
    //표정 그래프
    useEffect(() => {
        if (!isLoading && chartRefEmotion.current) {
            const donutChartEmotion = new Chart(chartRefEmotion.current, {
                type: 'doughnut',
                data: {
                    labels: ['웃음', '슬픔', '놀람', '무표정'],
                    datasets: [{
                        data: emotionData,
                        backgroundColor: ['#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0'],
                        hoverOffset: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'right',
                        },
                    },
                },
            });
            return () => {
                donutChartEmotion.destroy();
            };
        }
    }, [emotionData, isLoading]);
    //음성 radar 데이터 
    useEffect(() => {
        if (!isLoading && chartRefVoice.current) {

            const radarChartVoiceData = getNumericalVoiceData();

            const RadarChartVoice = new Chart(chartRefVoice.current, {
                type: 'radar',
                data: {
                    labels: ['빠르기', '연속성', '침묵횟수','정확도'],
                    datasets: [{
                        data: radarChartVoiceData,
                        borderWidth:2,
                    }]
                },
                options: {
                    scales: {
                        r: {
                            ticks: {
                                color: 'black',
                                font: {
                                    size: 14,
                                },
                                beginAtZero: true,
                                max: 100,
                                
                            },
                            angleLines: {
                                display: true
                            },
                            pointLabels:{
                                display: true,
                                font: {
                                    size: 17,
                                    weight: '700',
                                    family: 'Pretendard',
                                },
                                
                            }
                        }
                    },
                    plugins: {
                        legend: {
                            display: false,
                            //position: 'bottom'
                        },
                    },
                },
                responsive: true,
                maintainAspectRatio: false,
            });
            return () => {
                RadarChartVoice.destroy();
            };
        }
    }, [getNumericalVoiceData, isLoading]);
    //------------------------------------------------------
    //판별 함수
    function score(num){
        if (num >= 70){
            return '평균 이상';
        }
        else if (num <= 55){
            return '평균 이하';
        }
        else 
        {return '평균'};        
    }
    //--------------------------------------------------------------------------
    // 여기에 각 섹션에 해당하는 컴포넌트를 만듭니다.
    function Header() {
        return (
        <div className={styles['header-section']}> <h2>AI 리포트</h2>
        </div>);
    }
    // 왼쪽 판넬 섹션 컴포넌트
    function LeftPanel() {
        return ( 
        <div className={styles['left-panel']}>

            <div className={styles['chart-container-margin']}>
                <h2>시야 분석</h2>
                    <div className={styles['chart-container']}>
                    <canvas ref={chartRefEye} aria-label="시야 분석"></canvas>
                    </div>
            </div>
        
            <div className={styles['chart-container-margin']}>
                <h2>머리 위치분석</h2>
                    <div className={styles['chart-container']}>
                    <canvas ref={chartRefHead} aria-label="머리 위치 분석"></canvas>
                    </div>
            </div>

        </div>
        );
    }
    // 가운데 판넬 섹션 컴포넌트
    function CenterPanel() {
        return (
            <div className={styles['center-panel']}>
                <img src={kyungji} alt="Facial Analysis" />
                <p>ID: {userId}</p>
                <p>이름:{userName} </p>
                
                {/* 여기에 중앙 패널의 내용이 들어갑니다. */}
            </div>
        );
    }
    // 오른쪽 판넬 섹션 컴포넌트
    function RightPanel() {
        return (
            
            <div className={styles['right-panel']}>

                <div className={styles['chart-container-margin']}>
                <h2>표정 분석</h2>
                    <div className={styles['chart-container']}>
                        <canvas ref={chartRefEmotion} aria-label="표정 분석"></canvas>
                    </div>
                </div>
                <div className={styles['chart-container']}>
                    <h2>음성 분석</h2>
                        <div className={styles['radarchart-container']}>
                        <canvas ref={chartRefVoice} aria-label="음성 분석"></canvas>
                        </div>
                        <li><strong>피치 변동성:</strong> {voiceData.PITCH}</li>
                        <li><strong>발음:</strong> {voiceData.DICTION}</li>
                        
                </div>
            </div>
        );
    }
    // 밑에 판넬 컴포넌트
    function Footer() {
        // 결과에 대한 점수 평가 함수 사용
    const voiceScore = score(voiceData.SIMILARITY);
    const eyeScore = score(eyedata.reduce((a, b) => a + b) / eyedata.length); // 평균 시야 점수
    const emotionScore = score(emotionData.reduce((a, b) => a + b) / emotionData.length); // 평균 표정 점수
        
        return <div className={styles['footer-section']}> 
        {
            <div className={styles.result}>
                
                <div className={styles['result-title']}>
                    <h3>응시자 역량 분석</h3>
                </div>

                <div className={styles.resultcontent}>

                <p>{userName}님의 역량 분석 결과 입니다.</p>
                <br></br>
                
                <p>음성분석 결과: {voiceScore}</p>
                <p>음성 분석에서 {userName}님은 {voiceData.DICTION} 발음과 {voiceData.SPEED}의 빠르기를 보였습니다. 연속성과 침묵, 유사도 점수는 각각 {voiceData.CONTINUERS}, {voiceData.SILENCE}, {voiceData.SIMILARITY}로 나타났습니다.</p><p> 전반적으로 {voiceScore}인 음성 분석 결과를 보여주었습니다.</p>
                <br></br>

                <p>시야분석 결과: {eyeScore}</p>
                <p>{userName}님의 시야 분석에서는 중앙, 왼쪽, 오른쪽 시야와 깜빡임 횟수가 각각 {eyedata[0]}%, {eyedata[1]}%, {eyedata[2]}%, {eyedata[3]}회로 나타났습니다.</p><p>이는 {eyeScore}의 집중력과 주의 분산을 나타내는 지표가 될 수 있습니다.</p>

                <br></br>

                <p>표정분석 결과</p>
                <p> 웃음: {emotionData[0]}, 슬픔: {emotionData[1]}, 놀람: {emotionData[2]}, 무표정: {emotionData[3]}</p>

                <br></br>
                <p>종합적으로<br></br> {userName}님의 면접 과정에서 음성, 시야, 표정 분석을 통해 다각도의 역량을 평가하였습니다.<br></br> 각 분야에서의 세밀한 분석을 바탕으로 {userName}님의 면접 기술을 더욱 발전시킬 수 있는 구체적인 조언과 피드백을 제공하고자 합니다.</p>
                </div>
                
            </div>
        } 
        </div>;
    }
    // JSX 렌더링 부분.
    return (
        <div className={styles.App}>
            <div className={styles.Report}>
                <Header />
                <div className={styles['main-section']}>
                    <LeftPanel />
                    <CenterPanel />
                    <RightPanel />
                </div>
                <Footer />
            </div>
        </div>
    );
    }
    